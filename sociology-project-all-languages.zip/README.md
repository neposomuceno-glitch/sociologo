# Sociology Project — Multilingual Package

This archive contains the full sociology resource site in four languages.
Each language is a self-contained set of files in its own folder — open
`index-XX.html` in a browser to start browsing that language's version.

## Folders

- `es/` — Spanish (original). Includes the full deployment package:
  `GUIA-DE-DESPLIEGUE.md` (deployment guide), `wordpress-fragments/`
  (WordPress-ready HTML fragments), and `study-of-society-global-endeavor-es.html`
  (an earlier/duplicate homepage variant kept for structural parity).
- `en/` — English translation (11 pages).
- `fr/` — French translation (11 pages).
- `zh/` — Chinese (Simplified) translation (11 pages).

## Notes

- The English, French, and Chinese folders each contain the 11 core pages
  (homepage, sociology directory, current-events links, map links, heat map,
  maps-by-type, contributors, theorists, power & sponsors, works, license).
  They do not yet include WordPress fragments or a deployment guide —
  only the Spanish folder has those, since it was the original deployment.
- All internal links within each language folder are self-referential
  (e.g. `en/index-en.html` links only to other `-en.html` files) — keep
  each language's files together in their own folder for the links to work.
- Licensed under CC BY 4.0 — see the LICENSE-XX.html file in each folder.
